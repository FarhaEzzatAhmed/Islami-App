package com.example.islamii.callbacks

import java.text.ParsePosition

interface OnsouraClickListener {
// pastfed mn al poiton anhoo hyraga3lii al content pta3 al sora hasb al position bta3ha
    fun onSuraClick(position: Int, suraName :String)

}


