package com.example.islamii

object Constans {
    val EXTRA_SURA_POSITION ="SuperPosition"
    val EXTRA_SURA_Name = "SuraName"
    val EXTRA_Hades_POSITION ="hadesPosition"
    val EXTRA_Hades_Name = "hadesName"
    const val ALHAMDULALLAH ="الحمد لله"
    const val ALLAH_AKBAR ="الله اكبر"
    const val SUBHAN_ALLAH="سبحان الله"
    const val KHTEMA ="لا اله الا الله وحده لا شريك له ،له الملك وله الحمد ،وهو علي كل شيء قدير"
}