package com.example.islamii.quran_details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.islamii.R

class Quran_Details_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quran_details)
    }
}