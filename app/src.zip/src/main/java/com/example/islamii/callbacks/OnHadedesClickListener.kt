package com.example.islamii.callbacks

interface OnHadedesClickListener {
     fun onHadesclick(position:Int, hadesName :String)

}